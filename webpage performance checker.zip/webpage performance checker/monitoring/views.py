import json

from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .models import Alert, CheckResult, Visitor, Website, WebsiteVisitor
from .services import performance_breakdown, run_monitoring_check


def _safe_int(value, default):
    """Coerce a form value to int, falling back to *default* on parse errors."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _parse_add_form(request):
    """Build a new Website from the add/edit form POST data."""
    return {
        'name': request.POST.get('name', 'New website').strip() or 'New website',
        'url': request.POST.get('url', '').strip(),
        'expected_status_code': _safe_int(request.POST.get('expected_status_code'), 200),
        'timeout_seconds': _safe_int(request.POST.get('timeout_seconds'), 10),
        'response_time_threshold_ms': _safe_int(
            request.POST.get('response_time_threshold_ms'), 2500
        ),
        'expected_text': request.POST.get('expected_text', '').strip(),
        'ssl_required': request.POST.get('ssl_required') == 'on',
    }


def track_visitor(request):
    """Track unique visitors by IP address within a session window."""
    ip_address = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', '127.0.0.1'))
    # Handle multiple IPs in X-Forwarded-For header
    if ',' in ip_address:
        ip_address = ip_address.split(',')[0].strip()
    
    user_agent = request.META.get('HTTP_USER_AGENT', '')
    path = request.path
    
    # Use session to track recent visits
    session_key = f'visitor_{ip_address}'
    
    from django.utils import timezone
    from datetime import timedelta
    
    last_visit = request.session.get(session_key)
    if not last_visit:
        Visitor.objects.create(
            ip_address=ip_address,
            user_agent=user_agent,
            path=path,
        )
        request.session[session_key] = timezone.now().isoformat()
        request.session.modified = True
    else:
        try:
            from datetime import datetime
            last_visit_time = datetime.fromisoformat(last_visit)
            if timezone.is_naive(last_visit_time):
                last_visit_time = timezone.make_aware(last_visit_time)
            if timezone.now() - last_visit_time > timedelta(minutes=30):
                Visitor.objects.create(
                    ip_address=ip_address,
                    user_agent=user_agent,
                    path=path,
                )
                request.session[session_key] = timezone.now().isoformat()
                request.session.modified = True
        except (ValueError, TypeError):
            Visitor.objects.create(
                ip_address=ip_address,
                user_agent=user_agent,
                path=path,
            )
            request.session[session_key] = timezone.now().isoformat()
            request.session.modified = True


def track_website_visitor(request, website):
    """Track visitors to a specific website's monitoring page."""
    ip_address = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', '127.0.0.1'))
    if ',' in ip_address:
        ip_address = ip_address.split(',')[0].strip()
    
    user_agent = request.META.get('HTTP_USER_AGENT', '')
    
    # Use a unique session key for this website
    session_key = f'website_visitor_{website.id}_{ip_address}'
    
    from django.utils import timezone
    from datetime import timedelta

    last_visit = request.session.get(session_key)
    if not last_visit:
        WebsiteVisitor.objects.create(
            website=website,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        request.session[session_key] = timezone.now().isoformat()
        request.session.modified = True
    else:
        try:
            from datetime import datetime
            last_visit_time = datetime.fromisoformat(last_visit)
            if timezone.is_naive(last_visit_time):
                last_visit_time = timezone.make_aware(last_visit_time)
            if timezone.now() - last_visit_time > timedelta(minutes=30):
                WebsiteVisitor.objects.create(
                    website=website,
                    ip_address=ip_address,
                    user_agent=user_agent,
                )
                request.session[session_key] = timezone.now().isoformat()
                request.session.modified = True
        except (ValueError, TypeError):
            WebsiteVisitor.objects.create(
                website=website,
                ip_address=ip_address,
                user_agent=user_agent,
            )
            request.session[session_key] = timezone.now().isoformat()
            request.session.modified = True


def track_all_visitors(request, website):
    """Track all visitors to a website's page (no deduplication)."""
    ip_address = request.META.get('HTTP_X_FORWARDED_FOR', request.META.get('REMOTE_ADDR', '127.0.0.1'))
    if ',' in ip_address:
        ip_address = ip_address.split(',')[0].strip()
    
    user_agent = request.META.get('HTTP_USER_AGENT', '')
    
    WebsiteVisitor.objects.create(
        website=website,
        ip_address=ip_address,
        user_agent=user_agent,
    )


def get_visitor_count(website):
    """Get total visitor count for a website."""
    return WebsiteVisitor.objects.filter(website=website).count()


def dashboard(request):
    # Track general visitor
    track_visitor(request)
    
    if request.method == 'POST':
        Website.objects.create(**_parse_add_form(request))
        return redirect('dashboard')

    websites = Website.objects.all().prefetch_related('results__alerts')
    summaries = []
    for website in websites:
        latest = website.results.order_by('-checked_at').first()
        alerts = Alert.objects.filter(result__website=website).order_by('-created_at')[:5]
        # Track visitor to this website's monitoring page (with deduplication)
        track_website_visitor(request, website)
        visitor_count = WebsiteVisitor.objects.filter(website=website).count()
        # Build score trend (ascending) for the per-card sparkline chart.
        recent_results = list(website.results.order_by('-checked_at')[:20])[::-1]
        score_trend = [
            {
                'ts': r.checked_at.strftime('%Y-%m-%dT%H:%M:%S'),
                'score': r.performance_score,
            }
            for r in recent_results
        ]
        optimization_issues = []
        if latest and latest.optimization_issues:
            try:
                optimization_issues = json.loads(latest.optimization_issues)
            except (ValueError, TypeError):
                optimization_issues = []
        summaries.append({
            'website': website,
            'latest': latest,
            'alerts': alerts,
            'visitor_count': visitor_count,
            'score_trend': score_trend,
            'optimization_issues': optimization_issues,
        })

    total_visitors = Visitor.objects.count()
    # Aggregate stats for the overview summary bar.
    scored = [
        item['latest'] for item in summaries
        if item['latest'] and item['latest'].has_performance_data
    ]
    avg_score = round(sum(r.performance_score for r in scored) / len(scored)) if scored else 0
    sites_up = sum(
        1 for item in summaries if item['latest'] and item['latest'].is_available
    )
    total_checks = sum(
        item['latest'].total_checks for item in summaries if item['latest']
    )
    checks_today = CheckResult.objects.filter(
        checked_at__date=timezone.now().date()
    ).count()

    return render(request, 'monitoring/dashboard.html', {
        'summaries': summaries,
        'total_visitors': total_visitors,
        'total_sites': len(summaries),
        'avg_score': avg_score,
        'sites_up': sites_up,
        'total_checks': total_checks,
        'checks_today': checks_today,
    })


def history(request, website_id):
    website = get_object_or_404(Website, pk=website_id)
    # Track visitor to this website's page (always count)
    track_all_visitors(request, website)

    results = CheckResult.objects.filter(website=website).order_by('-checked_at')
    paginator = Paginator(results, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    visitor_count = WebsiteVisitor.objects.filter(website=website).count()
    # Trend data (ascending) for the Chart.js timeline.
    recent_results = list(CheckResult.objects.filter(website=website).order_by('-checked_at')[:30])[::-1]
    chart_data = [
        {
            'ts': r.checked_at.strftime('%Y-%m-%dT%H:%M:%S'),
            'score': r.performance_score,
            'response': r.response_time_ms,
            'ttfb': r.ttfb_ms,
        }
        for r in recent_results
    ]
    return render(request, 'monitoring/history.html', {
        'website': website,
        'page_obj': page_obj,
        'visitor_count': visitor_count,
        'chart_data': chart_data,
    })


def report(request, website_id):
    website = get_object_or_404(Website, pk=website_id)
    track_website_visitor(request, website)

    latest = website.results.order_by('-checked_at').first()
    if not latest:
        return render(request, 'monitoring/report.html', {
            'website': website,
            'latest': None,
            'breakdown': [],
            'score': 0,
            'chart_data': [],
            'optimization_issues': [],
            'headers': {},
            'grade_color': 'var(--muted)',
        })

    breakdown, score = performance_breakdown(
        latest.ttfb_ms,
        latest.total_time_ms,
        latest.total_transfer_bytes,
        latest.total_resource_count,
        latest.compressed,
        latest.cache_headers_ok,
    )
    try:
        optimization_issues = json.loads(latest.optimization_issues) if latest.optimization_issues else []
    except (ValueError, TypeError):
        optimization_issues = []
    try:
        headers = json.loads(latest.response_headers) if latest.response_headers else {}
    except (ValueError, TypeError):
        headers = {}

    recent_results = list(website.results.order_by('-checked_at')[:30])[::-1]
    chart_data = [
        {
            'ts': r.checked_at.strftime('%Y-%m-%dT%H:%M:%S'),
            'score': r.performance_score,
            'response': r.response_time_ms,
            'ttfb': r.ttfb_ms,
        }
        for r in recent_results
    ]

    grade_colors = {
        'A': 'var(--success)',
        'B': 'var(--info)',
        'C': 'var(--warning)',
        'D': 'var(--accent)',
        'E': '#ff8040',
        'F': 'var(--danger)',
    }
    grade_color = grade_colors.get(latest.performance_grade, 'var(--muted)')

    return render(request, 'monitoring/report.html', {
        'website': website,
        'latest': latest,
        'breakdown': breakdown,
        'score': score,
        'chart_data': chart_data,
        'optimization_issues': optimization_issues,
        'headers': headers,
        'grade_color': grade_color,
    })


def edit_website(request, website_id):
    website = get_object_or_404(Website, pk=website_id)
    if request.method == 'POST':
        data = _parse_add_form(request)
        website.name = data['name']
        website.url = data['url']
        website.expected_status_code = data['expected_status_code']
        website.timeout_seconds = data['timeout_seconds']
        website.response_time_threshold_ms = data['response_time_threshold_ms']
        website.expected_text = data['expected_text']
        website.ssl_required = data['ssl_required']
        website.save()
        return redirect('dashboard')
    return render(request, 'monitoring/edit_website.html', {'website': website})


def delete_website(request, website_id):
    website = get_object_or_404(Website, pk=website_id)
    website.delete()
    return redirect('dashboard')


def run_check(request, website_id):
    website = get_object_or_404(Website, pk=website_id)
    run_monitoring_check(website)
    return redirect('dashboard')
