from django import template

register = template.Library()


@register.filter
def compact_bytes(value):
    """Format a byte count compactly, e.g. 0 -> '0 B', 559 -> '559 B', 17385 -> '17.0 KB'."""
    try:
        value = int(value)
    except (TypeError, ValueError):
        return '--'
    if value < 1024:
        return f'{value} B'
    kb = value / 1024
    if kb < 1024:
        return f'{kb:.1f} KB'
    mb = kb / 1024
    return f'{mb:.1f} MB'
