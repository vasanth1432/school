from django.contrib import admin

from .models import Alert, CheckResult, Visitor, Website, WebsiteVisitor

@admin.register(Website)
class WebsiteAdmin(admin.ModelAdmin):
    list_display = ['name', 'url', 'created_at']
    list_filter = ['ssl_required', 'created_at']


@admin.register(CheckResult)
class CheckResultAdmin(admin.ModelAdmin):
    list_display = ['website', 'checked_at', 'is_available', 'response_time_ms']
    list_filter = ['is_available', 'checked_at']


@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display = ['severity', 'result', 'created_at']
    list_filter = ['severity', 'created_at']


@admin.register(Visitor)
class VisitorAdmin(admin.ModelAdmin):
    list_display = ['ip_address', 'visited_at', 'path']
    list_filter = ['visited_at']
    readonly_fields = ['ip_address', 'user_agent', 'visited_at', 'path']


@admin.register(WebsiteVisitor)
class WebsiteVisitorAdmin(admin.ModelAdmin):
    list_display = ['website', 'ip_address', 'visited_at']
    list_filter = ['website', 'visited_at']
    readonly_fields = ['website', 'ip_address', 'user_agent', 'visited_at']
