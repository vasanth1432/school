from django.db import models


class Website(models.Model):
    name = models.CharField(max_length=200)
    url = models.URLField()
    expected_status_code = models.PositiveIntegerField(default=200)
    timeout_seconds = models.PositiveIntegerField(default=10)
    response_time_threshold_ms = models.PositiveIntegerField(default=2500)
    expected_text = models.CharField(max_length=200, blank=True)
    ssl_required = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.name


class CheckResult(models.Model):
    website = models.ForeignKey(Website, related_name='results', on_delete=models.CASCADE)
    checked_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    is_available = models.BooleanField(default=False)
    status_code = models.PositiveIntegerField(default=0)
    response_time_ms = models.PositiveIntegerField(default=0)
    dns_lookup_ms = models.PositiveIntegerField(default=0)
    page_load_time_ms = models.PositiveIntegerField(default=0)
    ssl_valid = models.BooleanField(default=True)
    content_found = models.BooleanField(default=True)
    response_headers = models.TextField(blank=True)
    error_message = models.TextField(blank=True)
    has_alerts = models.BooleanField(default=False)
    availability_uptime_ratio = models.FloatField(default=0.0)
    total_checks = models.PositiveIntegerField(default=0)
    failed_checks = models.PositiveIntegerField(default=0)
    error_rate_percent = models.FloatField(default=0.0)
    dns_hostname = models.CharField(max_length=200, blank=True)
    header_server = models.CharField(max_length=200, blank=True)
    cache_control = models.CharField(max_length=200, blank=True)
    content_type = models.CharField(max_length=200, blank=True)
    ssl_expiry_date = models.DateTimeField(null=True, blank=True)
    ssl_issuer = models.CharField(max_length=200, blank=True)
    ssl_days_to_expiry = models.IntegerField(null=True, blank=True)

    # Performance metrics
    ttfb_ms = models.PositiveIntegerField(default=0)
    total_time_ms = models.PositiveIntegerField(default=0)
    html_size_bytes = models.PositiveIntegerField(default=0)
    total_transfer_bytes = models.PositiveIntegerField(default=0)
    total_resource_count = models.PositiveIntegerField(default=0)
    compressed = models.BooleanField(default=False)
    cache_headers_ok = models.BooleanField(default=True)
    performance_score = models.PositiveIntegerField(default=0)
    performance_grade = models.CharField(max_length=2, blank=True, default='F')
    optimization_issues = models.TextField(blank=True, default='[]')

    @property
    def has_performance_data(self) -> bool:
        """True when a check was produced by the performance-aware checker."""
        return bool(self.ttfb_ms or self.total_transfer_bytes or self.performance_score)

    def __str__(self) -> str:
        return f'{self.website.name} @ {self.checked_at:%Y-%m-%d %H:%M}'


class Alert(models.Model):
    result = models.ForeignKey(CheckResult, related_name='alerts', on_delete=models.CASCADE)
    severity = models.CharField(max_length=20, choices=[('low', 'Low'), ('medium', 'Medium'), ('high', 'High')])
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return f'{self.severity}: {self.message}'


class Visitor(models.Model):
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField(blank=True)
    visited_at = models.DateTimeField(auto_now_add=True)
    path = models.CharField(max_length=500, blank=True)

    class Meta:
        ordering = ['-visited_at']
        indexes = [
            models.Index(fields=['ip_address']),
            models.Index(fields=['visited_at']),
        ]

    def __str__(self) -> str:
        return f'{self.ip_address} @ {self.visited_at:%Y-%m-%d %H:%M}'


class WebsiteVisitor(models.Model):
    """Track visitors to each website's monitoring page."""
    website = models.ForeignKey(Website, related_name='visitors', on_delete=models.CASCADE)
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField(blank=True)
    visited_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-visited_at']
        indexes = [
            models.Index(fields=['website', 'ip_address']),
            models.Index(fields=['visited_at']),
        ]

    def __str__(self) -> str:
        return f'{self.website.name} - {self.ip_address} @ {self.visited_at:%Y-%m-%d %H:%M}'
