from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('monitoring', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='checkresult',
            name='availability_uptime_ratio',
            field=models.FloatField(default=0.0),
        ),
        migrations.AddField(
            model_name='checkresult',
            name='error_rate_percent',
            field=models.FloatField(default=0.0),
        ),
        migrations.AddField(
            model_name='checkresult',
            name='failed_checks',
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name='checkresult',
            name='page_load_time_ms',
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name='checkresult',
            name='total_checks',
            field=models.PositiveIntegerField(default=0),
        ),
    ]
