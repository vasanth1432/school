from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('monitoring', '0002_checkresult_monitoring_metrics'),
    ]

    operations = [
        migrations.AddField(
            model_name='checkresult',
            name='cache_control',
            field=models.CharField(blank=True, max_length=200),
        ),
        migrations.AddField(
            model_name='checkresult',
            name='content_type',
            field=models.CharField(blank=True, max_length=200),
        ),
        migrations.AddField(
            model_name='checkresult',
            name='dns_hostname',
            field=models.CharField(blank=True, max_length=200),
        ),
        migrations.AddField(
            model_name='checkresult',
            name='header_server',
            field=models.CharField(blank=True, max_length=200),
        ),
    ]
