from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import patch

from django.test import TestCase
from django.urls import reverse

from .models import Alert, CheckResult, Website
from .services import SSLCertificateInfo, run_monitoring_check


def _fake_response(status_code=200, elapsed_ms=200):
    """Build a mocked requests.Response stand-in used across tests."""
    return SimpleNamespace(
        status_code=status_code,
        elapsed=timedelta(milliseconds=elapsed_ms),
        headers={'content-type': 'text/html', 'server': 'nginx'},
        url='https://example.com/',
        content=b'Example domain',
        raise_for_status=lambda: None,
        text='Example domain',
    )


class MonitoringServiceTests(TestCase):
    def setUp(self):
        self.website = Website.objects.create(
            name='Example site',
            url='https://example.com',
            expected_status_code=200,
            timeout_seconds=5,
            response_time_threshold_ms=2500,
            ssl_required=True,
        )

    @patch('monitoring.services.measure_dns_resolution')
    @patch('monitoring.services.check_ssl_certificate')
    @patch('monitoring.services.requests.get')
    def test_run_monitoring_check_marks_successful_site(self, mock_get, mock_ssl, mock_dns):
        mock_get.return_value = _fake_response()
        mock_dns.return_value = 42
        mock_ssl.return_value = SSLCertificateInfo(
            is_valid=True, expiry_date=datetime(2030, 1, 1, tzinfo=timezone.utc)
        )

        result = run_monitoring_check(self.website)

        self.assertEqual(result.status_code, 200)
        self.assertTrue(result.is_available)
        self.assertFalse(result.has_alerts)
        self.assertEqual(result.alerts.count(), 0)
        self.assertTrue(result.ssl_valid)
        # Expected days is computed from the real wall clock (expiry is 2030-01-01).
        expected_days = (datetime(2030, 1, 1, tzinfo=timezone.utc) - datetime.now(timezone.utc)).days
        self.assertEqual(result.ssl_days_to_expiry, expected_days)

    @patch('monitoring.services.measure_dns_resolution')
    @patch('monitoring.services.check_ssl_certificate')
    @patch('monitoring.services.requests.get')
    def test_run_monitoring_check_creates_alert_for_slow_response(self, mock_get, mock_ssl, mock_dns):
        mock_get.return_value = _fake_response(elapsed_ms=4000)
        mock_dns.return_value = 42
        mock_ssl.return_value = SSLCertificateInfo(
            is_valid=True, expiry_date=datetime(2030, 1, 1, tzinfo=timezone.utc)
        )

        result = run_monitoring_check(self.website)

        self.assertTrue(result.has_alerts)
        self.assertTrue(Alert.objects.filter(result=result).exists())

    @patch('monitoring.services.measure_dns_resolution')
    @patch('monitoring.services.check_ssl_certificate')
    @patch('monitoring.services.requests.get')
    def test_run_monitoring_check_records_header_and_content_metrics(self, mock_get, mock_ssl, mock_dns):
        mock_get.return_value = _fake_response()
        mock_dns.return_value = 42
        mock_ssl.return_value = SSLCertificateInfo(is_valid=True)

        result = run_monitoring_check(self.website)

        self.assertIn('server', result.response_headers)
        self.assertTrue(result.content_found)
        self.assertEqual(result.status_code, 200)

    @patch('monitoring.services.check_ssl_certificate')
    @patch('monitoring.services.measure_dns_resolution')
    @patch('monitoring.services.requests.get')
    def test_run_monitoring_check_collects_dns_ssl_and_page_load_metrics(self, mock_get, mock_dns, mock_ssl):
        mock_get.return_value = _fake_response()
        mock_dns.return_value = 115
        mock_ssl.return_value = SSLCertificateInfo(
            is_valid=True,
            expiry_date=datetime(2030, 1, 1, tzinfo=timezone.utc),
            issuer='CN=Example CA',
        )

        result = run_monitoring_check(self.website)

        self.assertEqual(result.page_load_time_ms, 200)
        self.assertEqual(result.dns_lookup_ms, 115)
        self.assertTrue(result.ssl_valid)
        self.assertEqual(result.ssl_issuer, 'CN=Example CA')
        self.assertEqual(result.error_rate_percent, 0.0)

    @patch('monitoring.services.measure_dns_resolution')
    @patch('monitoring.services.check_ssl_certificate')
    @patch('monitoring.services.requests.get')
    def test_run_monitoring_check_skips_ssl_when_not_required(self, mock_get, mock_ssl, mock_dns):
        mock_get.return_value = _fake_response()
        mock_dns.return_value = 42
        self.website.ssl_required = False
        self.website.save()

        result = run_monitoring_check(self.website)

        mock_ssl.assert_not_called()
        self.assertTrue(result.ssl_valid)
        self.assertIsNone(result.ssl_expiry_date)

    @patch('monitoring.services.measure_dns_resolution')
    @patch('monitoring.services.check_ssl_certificate')
    @patch('monitoring.services.requests.get')
    def test_run_monitoring_check_alerts_on_invalid_ssl(self, mock_get, mock_ssl, mock_dns):
        mock_get.return_value = _fake_response()
        mock_dns.return_value = 42
        mock_ssl.return_value = SSLCertificateInfo(is_valid=False)

        result = run_monitoring_check(self.website)

        self.assertTrue(result.has_alerts)
        self.assertFalse(result.ssl_valid)
        self.assertTrue(Alert.objects.filter(result=result, severity='high').exists())

    @patch('monitoring.services.measure_dns_resolution')
    @patch('monitoring.services.check_ssl_certificate')
    @patch('monitoring.services.requests.get')
    def test_run_monitoring_check_alerts_when_ssl_expiring_soon(self, mock_get, mock_ssl, mock_dns):
        mock_get.return_value = _fake_response()
        mock_dns.return_value = 42
        expiring = datetime.now(timezone.utc) + timedelta(days=5)
        mock_ssl.return_value = SSLCertificateInfo(is_valid=True, expiry_date=expiring)

        result = run_monitoring_check(self.website)

        self.assertTrue(result.has_alerts)
        self.assertTrue(
            Alert.objects.filter(result=result, severity='medium', message__contains='expires in').exists()
        )
        # The exact day count can flop by one at the day boundary; verify a sane range.
        self.assertIsNotNone(result.ssl_days_to_expiry)
        self.assertGreaterEqual(result.ssl_days_to_expiry, 4)
        self.assertLessEqual(result.ssl_days_to_expiry, 5)


class DashboardViewTests(TestCase):
    def setUp(self):
        self.website = Website.objects.create(
            name='Example site',
            url='https://example.com',
            ssl_required=True,
        )

    def test_dashboard_renders_with_websites(self):
        response = self.client.get(reverse('dashboard'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Website Performance Dashboard')
        self.assertContains(response, 'Example site')

    def test_dashboard_adds_website_with_all_fields(self):
        response = self.client.post(reverse('dashboard'), {
            'name': 'New site',
            'url': 'https://newsite.com',
            'expected_status_code': 201,
            'timeout_seconds': 15,
            'response_time_threshold_ms': 1500,
            'expected_text': 'welcome',
            'ssl_required': 'on',
        })

        self.assertRedirects(response, reverse('dashboard'))
        website = Website.objects.get(url='https://newsite.com')
        self.assertEqual(website.expected_status_code, 201)
        self.assertEqual(website.timeout_seconds, 15)
        self.assertEqual(website.response_time_threshold_ms, 1500)
        self.assertEqual(website.expected_text, 'welcome')
        self.assertTrue(website.ssl_required)

    def test_dashboard_adds_website_without_ssl(self):
        response = self.client.post(reverse('dashboard'), {
            'name': 'Plain site',
            'url': 'https://plainsite.com',
        })

        self.assertRedirects(response, reverse('dashboard'))
        self.assertFalse(Website.objects.get(url='https://plainsite.com').ssl_required)

    def test_dashboard_adds_website_with_invalid_int_falls_back_to_default(self):
        response = self.client.post(reverse('dashboard'), {
            'name': 'Odd site',
            'url': 'https://oddsite.com',
            'expected_status_code': 'not-a-number',
            'timeout_seconds': '',
        })

        self.assertRedirects(response, reverse('dashboard'))
        website = Website.objects.get(url='https://oddsite.com')
        self.assertEqual(website.expected_status_code, 200)
        self.assertEqual(website.timeout_seconds, 10)


class HistoryViewTests(TestCase):
    def setUp(self):
        self.website = Website.objects.create(
            name='Example site',
            url='https://example.com',
        )

    def test_history_renders_result_rows(self):
        CheckResult.objects.create(website=self.website, is_available=True, response_time_ms=150)
        CheckResult.objects.create(website=self.website, is_available=False, response_time_ms=900)

        response = self.client.get(reverse('history', args=[self.website.id]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Example site')
        self.assertContains(response, 'Up')
        self.assertContains(response, 'Down')

    def test_history_paginates_at_ten_per_page(self):
        for i in range(15):
            CheckResult.objects.create(website=self.website, is_available=True, response_time_ms=i)

        page_one = self.client.get(reverse('history', args=[self.website.id]))
        page_two = self.client.get(reverse('history', args=[self.website.id]), {'page': 2})

        self.assertEqual(page_one.context['page_obj'].paginator.num_pages, 2)
        self.assertEqual(len(page_one.context['page_obj'].object_list), 10)
        self.assertEqual(len(page_two.context['page_obj'].object_list), 5)

    def test_history_returns_404_for_missing_website(self):
        response = self.client.get(reverse('history', args=[999]))

        self.assertEqual(response.status_code, 404)


class EditAndDeleteViewTests(TestCase):
    def setUp(self):
        self.website = Website.objects.create(
            name='Example site',
            url='https://example.com',
            response_time_threshold_ms=2500,
            ssl_required=True,
        )

    def test_edit_form_renders_current_values(self):
        response = self.client.get(reverse('edit_website', args=[self.website.id]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'value="https://example.com"')

    def test_edit_website_updates_fields(self):
        response = self.client.post(reverse('edit_website', args=[self.website.id]), {
            'name': 'Renamed site',
            'url': 'https://renamed.com',
            'expected_status_code': 301,
            'timeout_seconds': 20,
            'response_time_threshold_ms': 500,
            'expected_text': 'hello',
        })

        self.assertRedirects(response, reverse('dashboard'))
        self.website.refresh_from_db()
        self.assertEqual(self.website.name, 'Renamed site')
        self.assertEqual(self.website.url, 'https://renamed.com')
        self.assertEqual(self.website.expected_status_code, 301)
        self.assertEqual(self.website.expected_text, 'hello')
        # Checkbox absent -> ssl requirement turned off
        self.assertFalse(self.website.ssl_required)

    def test_delete_website_removes_website_and_results(self):
        CheckResult.objects.create(website=self.website, is_available=True)

        response = self.client.post(reverse('delete_website', args=[self.website.id]))

        self.assertRedirects(response, reverse('dashboard'))
        self.assertEqual(Website.objects.count(), 0)
        self.assertEqual(CheckResult.objects.count(), 0)

    def test_run_check_redirects_and_calls_service(self):
        with patch('monitoring.views.run_monitoring_check') as mock_run:
            response = self.client.post(reverse('run_check', args=[self.website.id]))
            mock_run.assert_called_once()

        self.assertRedirects(response, reverse('dashboard'))
