from django.urls import path

from .views import dashboard, delete_website, edit_website, history, report, run_check

urlpatterns = [
    path('', dashboard, name='dashboard'),
    path('history/<int:website_id>/', history, name='history'),
    path('report/<int:website_id>/', report, name='report'),
    path('check/<int:website_id>/', run_check, name='run_check'),
    path('edit/<int:website_id>/', edit_website, name='edit_website'),
    path('delete/<int:website_id>/', delete_website, name='delete_website'),
]
