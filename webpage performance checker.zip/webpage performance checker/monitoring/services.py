from __future__ import annotations

import datetime as dt
import json
import socket
import smtplib
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from html.parser import HTMLParser
from typing import List, Optional, Tuple
from urllib.parse import urljoin, urlparse

import requests
from django.conf import settings
from django.utils import timezone

from .models import Alert, CheckResult, Website


class MonitoringError(Exception):
    pass


# Days before certificate expiry that triggers an alert.
SSL_EXPIRY_ALERT_DAYS = 14
# Port used for TLS/SSL certificate checks.
SSL_PORT = 443
# Maximum number of sub-resources we audit per check to stay fast.
MAX_AUDIT_RESOURCES = 20
# An asset larger than this (bytes) is flagged as a bloat issue.
LARGE_ASSET_BYTES = 500_000


@dataclass
class SSLCertificateInfo:
    """Result of a TLS/SSL certificate check for a hostname."""

    is_valid: bool = False
    expiry_date: Optional[dt.datetime] = None
    issuer: str = ''

    @property
    def days_to_expiry(self) -> Optional[int]:
        if not self.expiry_date:
            return None
        delta = self.expiry_date - dt.datetime.now(dt.timezone.utc)
        return max(int(delta.total_seconds() // 86400), 0)


def _extract_hostname(url: str) -> str:
    """Extract the bare hostname from a URL (e.g. 'https://a.com/x' -> 'a.com')."""
    netloc = url.split('//')[-1].split('/')[0]
    return netloc.split('@')[-1].split(':')[0].strip()


def _parse_cert_expiry(value: Optional[str]) -> Optional[dt.datetime]:
    """Parse the RFC 5280 'notAfter' timestamp returned by getpeercert()."""
    if not value:
        return None
    try:
        expiry = dt.datetime.strptime(value, '%b %d %H:%M:%S %Y %Z')
    except (ValueError, TypeError):
        return None
    if expiry.tzinfo is None:
        expiry = expiry.replace(tzinfo=dt.timezone.utc)
    return expiry


def check_ssl_certificate(url: str) -> SSLCertificateInfo:
    """Validate the TLS/SSL certificate for a URL's hostname.

    Establishes a real TLS handshake and inspects the peer certificate,
    returning whether it is valid, its expiry date and its issuer.
    """
    hostname = _extract_hostname(url)
    if not hostname:
        return SSLCertificateInfo(is_valid=False)

    context = ssl.create_default_context()
    try:
        with socket.create_connection((hostname, SSL_PORT), timeout=10) as conn:
            with context.wrap_socket(conn, server_hostname=hostname) as tls_sock:
                cert = tls_sock.getpeercert()
                if not cert:
                    return SSLCertificateInfo(is_valid=False)

                expiry_date = _parse_cert_expiry(cert.get('notAfter'))

                issuer = ''
                try:
                    issuer = ', '.join(
                        f'{key}={value}'
                        for key, value in dict(x[0] for x in cert.get('issuer', [])).items()
                    )
                except (ValueError, TypeError):
                    issuer = ''

                is_valid = (
                    expiry_date is not None
                    and expiry_date > dt.datetime.now(dt.timezone.utc)
                )
                return SSLCertificateInfo(
                    is_valid=is_valid,
                    expiry_date=expiry_date,
                    issuer=issuer,
                )
    except (ssl.SSLError, ssl.CertificateError, OSError, socket.error):
        return SSLCertificateInfo(is_valid=False)


def measure_dns_resolution(hostname: str) -> int:
    start = timezone.now()
    socket.gethostbyname(hostname)
    elapsed_ms = int((timezone.now() - start).total_seconds() * 1000)
    return max(elapsed_ms, 0)


def _fetch_page(url: str, timeout: int):
    """Fetch a URL with streaming to measure TTFB and total time separately.

    Returns (status_code, ttfb_ms, total_time_ms, body_bytes, headers, error).
    """
    start = timezone.now()
    parts: List[bytes] = []
    ttfb_ms = 0
    first_byte_at = None
    try:
        response = requests.get(
            url,
            timeout=timeout,
            headers={'User-Agent': 'performance-checker/1.0'},
            stream=True,
        )
    except requests.RequestException as exc:
        return None, 0, 0, b'', {}, str(exc)

    try:
        for chunk in response.iter_content(chunk_size=4096):
            if first_byte_at is None:
                first_byte_at = timezone.now()
                ttfb_ms = int((first_byte_at - start).total_seconds() * 1000)
            parts.append(chunk)
    except (requests.RequestException, TimeoutError):
        # Partial download; record what we have and continue.
        pass

    if first_byte_at is None:
        # Empty body; TTFB is the time after the request completed.
        ttfb_ms = int((timezone.now() - start).total_seconds() * 1000)

    total_time_ms = int((timezone.now() - start).total_seconds() * 1000)
    status_code = response.status_code
    headers = dict(response.headers)
    body = b''.join(parts)
    response.close()
    return status_code, ttfb_ms, total_time_ms, body, headers, None


class ResourceExtractor(HTMLParser):
    """Extract asset URLs from an HTML document."""

    def __init__(self):
        super().__init__()
        self.resources: List[str] = []
        self._src_tags = {'script', 'img', 'iframe', 'source', 'video', 'audio', 'embed'}

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, Optional[str]]]) -> None:
        attribute_map = dict(attrs)
        url = None
        if tag in self._src_tags:
            url = attribute_map.get('src') or attribute_map.get('data-src')
        elif tag == 'link':
            rel = attribute_map.get('rel', '')
            if isinstance(rel, str) and any(
                token in rel for token in ('stylesheet', 'preload', 'icon', 'preconnect')
            ):
                url = attribute_map.get('href')
        if url:
            self.resources.append(url)


def _fetch_resource_headers(url: str, timeout: int):
    """Get the size and headers for a single sub-resource.

    Prefers HEAD; falls back to a streaming GET so we never download the body.
    """
    try:
        resp = requests.head(
            url,
            timeout=timeout,
            allow_redirects=True,
            headers={'User-Agent': 'performance-checker/1.0'},
        )
        size = int(resp.headers.get('content-length', 0) or 0)
        return size, dict(resp.headers), None
    except requests.RequestException:
        try:
            resp = requests.get(
                url,
                timeout=timeout,
                stream=True,
                allow_redirects=True,
                headers={'User-Agent': 'performance-checker/1.0'},
            )
            size = int(resp.headers.get('content-length', 0) or 0)
            headers = dict(resp.headers)
            resp.close()
            return size, headers, None
        except requests.RequestException as exc:
            return 0, {}, str(exc)


def audit_resources(html_text: str, base_url: str, timeout: int):
    """Parse HTML and estimate the page's weight and sub-resource count.

    Returns (total_transfer_bytes, resource_count, issues, cache_headers_ok).
    """
    parser = ResourceExtractor()
    parser.resources = []
    try:
        parser.feed(html_text)
    except Exception:
        return 0, 0, [], True

    seen = set()
    issues: List[str] = []
    total_bytes = 0
    count = 0
    cache_headers_ok = True

    for raw_url in parser.resources:
        if count >= MAX_AUDIT_RESOURCES:
            break
        try:
            full = urljoin(base_url, raw_url.strip())
        except (ValueError, AttributeError):
            continue
        parsed = urlparse(full)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc:
            continue
        if full in seen:
            continue
        seen.add(full)

        size, headers, error = _fetch_resource_headers(full, timeout)
        if error or size <= 0:
            continue

        count += 1
        total_bytes += size

        content_type = headers.get('content-type', '').lower()
        encoding = headers.get('content-encoding', '').lower()
        is_static = (
            'text/css' in content_type
            or 'javascript' in content_type
            or 'image/' in content_type
            or 'font/' in content_type
            or 'application/json' in content_type
        )

        if is_static and encoding not in ('gzip', 'br', 'deflate'):
            issues.append(f'Uncompressed asset: {full[:80]}')

        if is_static:
            has_cache = any(
                header in headers for header in ('cache-control', 'expires', 'etag', 'last-modified')
            )
            if not has_cache:
                cache_headers_ok = False
                issues.append(f'Missing cache headers: {full[:80]}')

        if size > LARGE_ASSET_BYTES:
            issues.append(f'Large asset ({size // 1024}KB): {full[:80]}')

    # De-duplicate while preserving order.
    issues = list(dict.fromkeys(issues))
    return total_bytes, count, issues, cache_headers_ok


def performance_breakdown(
    ttfb_ms: int,
    total_time_ms: int,
    total_transfer_bytes: int,
    resource_count: int,
    compressed: bool,
    cache_headers_ok: bool,
) -> Tuple[List[dict], int]:
    """Return a per-signal score breakdown and the resulting 0-100 score.

    Each row describes one signal with the points it cost and a short reason,
    so the UI can explain *why* a site scored the way it did.
    """
    rows: List[dict] = []
    deductions = 0.0

    def add(label: str, lost: float, detail: str, status: str) -> None:
        nonlocal deductions
        rows.append({
            'label': label,
            'points_lost': int(round(lost)),
            'detail': detail,
            'status': status,
        })
        deductions += lost

    if ttfb_ms > 0:
        if ttfb_ms < 200:
            add('TTFB', 0, f'{ttfb_ms}ms — ideal (<200ms)', 'ok')
        elif ttfb_ms < 600:
            add('TTFB', (ttfb_ms - 200) / 400 * 10, f'{ttfb_ms}ms — acceptable (200–600ms)', 'warn')
        else:
            add('TTFB', min(30, 10 + (ttfb_ms - 600) / 600 * 20), f'{ttfb_ms}ms — slow (>600ms)', 'bad')
    else:
        add('TTFB', 0, 'No data', 'ok')

    if total_time_ms > 0:
        if total_time_ms < 1000:
            add('Response', 0, f'{total_time_ms}ms — fast (<1s)', 'ok')
        elif total_time_ms < 3000:
            add('Response', (total_time_ms - 1000) / 2000 * 15, f'{total_time_ms}ms — moderate (1–3s)', 'warn')
        else:
            add('Response', min(35, 15 + (total_time_ms - 3000) / 4000 * 20), f'{total_time_ms}ms — slow (>3s)', 'bad')
    else:
        add('Response', 0, 'No data', 'ok')

    if total_transfer_bytes > 0:
        mb = total_transfer_bytes / (1024 * 1024)
        if mb <= 2:
            add('Page weight', 0, f'{mb:.2f}MB — light (≤2MB)', 'ok')
        elif mb <= 5:
            add('Page weight', (mb - 2) / 3 * 10, f'{mb:.2f}MB — moderate (2–5MB)', 'warn')
        else:
            add('Page weight', min(25, 10 + (mb - 5) / 5 * 15), f'{mb:.2f}MB — heavy (>5MB)', 'bad')
    else:
        add('Page weight', 0, 'No data', 'ok')

    if resource_count > 0:
        if resource_count <= 30:
            add('Resources', 0, f'{resource_count} — fine (≤30)', 'ok')
        elif resource_count <= 80:
            add('Resources', (resource_count - 30) / 50 * 10, f'{resource_count} — many (30–80)', 'warn')
        else:
            add('Resources', min(20, 10 + (resource_count - 80) / 80 * 10), f'{resource_count} — excessive (>80)', 'bad')
    else:
        add('Resources', 0, 'No data', 'ok')

    add(
        'Compression',
        0 if compressed else 5,
        'Enabled (gzip/br)' if compressed else 'Missing (gzip/br)',
        'ok' if compressed else 'bad',
    )
    add(
        'Cache headers',
        0 if cache_headers_ok else 5,
        'Present' if cache_headers_ok else 'Missing',
        'ok' if cache_headers_ok else 'warn',
    )

    score = max(0, min(100, int(round(100 - deductions))))
    return rows, score


def compute_performance_score(
    ttfb_ms: int,
    total_time_ms: int,
    total_transfer_bytes: int,
    resource_count: int,
    compressed: bool,
    cache_headers_ok: bool,
) -> int:
    """Produce a 0-100 performance score from the measured metrics."""
    _, score = performance_breakdown(
        ttfb_ms,
        total_time_ms,
        total_transfer_bytes,
        resource_count,
        compressed,
        cache_headers_ok,
    )
    return score


def grade_for_score(score: int) -> str:
    """Map a 0-100 score to an A-F grade."""
    if score >= 90:
        return 'A'
    if score >= 80:
        return 'B'
    if score >= 70:
        return 'C'
    if score >= 60:
        return 'D'
    if score >= 50:
        return 'E'
    return 'F'


def run_monitoring_check(website: Website) -> CheckResult:
    started_at = timezone.now()
    result = CheckResult.objects.create(
        website=website,
        checked_at=started_at,
        is_available=False,
        status_code=0,
        response_time_ms=0,
        dns_lookup_ms=0,
        ssl_valid=True,
        content_found=True,
        response_headers='{}',
        ttfb_ms=0,
        total_time_ms=0,
        html_size_bytes=0,
        total_transfer_bytes=0,
        total_resource_count=0,
        compressed=False,
        cache_headers_ok=True,
        performance_score=0,
        performance_grade='F',
        optimization_issues='[]',
    )

    status_code, ttfb_ms, total_time_ms, body, headers, request_error = _fetch_page(
        website.url, website.timeout_seconds
    )

    if request_error:
        result.error_message = request_error
        result.has_alerts = True
        result.save(update_fields=['error_message', 'has_alerts', 'checked_at'])
        Alert.objects.create(
            result=result,
            severity='high',
            message=f'Website unavailable: {request_error}',
        )
        send_alert_email(website, result, request_error)
        return result

    hostname = _extract_hostname(website.url)
    content_text = body.decode('utf-8', errors='replace')
    content_encoding = headers.get('content-encoding', '').lower()

    result.status_code = status_code
    result.response_time_ms = total_time_ms
    result.total_time_ms = total_time_ms
    result.ttfb_ms = ttfb_ms
    result.page_load_time_ms = total_time_ms
    result.html_size_bytes = len(body)
    result.response_headers = json.dumps(headers, default=str)
    result.is_available = status_code == website.expected_status_code
    result.dns_lookup_ms = measure_dns_resolution(hostname)
    result.dns_hostname = hostname
    result.header_server = headers.get('server', '')
    result.cache_control = headers.get('cache-control', '')
    result.content_type = headers.get('content-type', '')
    result.compressed = content_encoding in ('gzip', 'br', 'deflate')

    # Resource audit (page weight, resource count, compression/cache checks).
    resources_bytes, resource_count, issues, cache_headers_ok = audit_resources(
        content_text, website.url, timeout=website.timeout_seconds
    )
    result.total_transfer_bytes = len(body) + resources_bytes
    result.total_resource_count = resource_count
    result.cache_headers_ok = cache_headers_ok
    result.optimization_issues = json.dumps(issues, default=str)

    if website.ssl_required:
        ssl_info = check_ssl_certificate(website.url)
        result.ssl_valid = ssl_info.is_valid
        result.ssl_expiry_date = ssl_info.expiry_date
        result.ssl_issuer = ssl_info.issuer
        result.ssl_days_to_expiry = ssl_info.days_to_expiry

        if not ssl_info.is_valid:
            Alert.objects.create(
                result=result,
                severity='high',
                message='SSL certificate invalid or expired',
            )
            result.has_alerts = True
        elif (
            ssl_info.days_to_expiry is not None
            and ssl_info.days_to_expiry <= SSL_EXPIRY_ALERT_DAYS
        ):
            Alert.objects.create(
                result=result,
                severity='medium',
                message=(
                    f'SSL certificate expires in {ssl_info.days_to_expiry} day(s) '
                    f'({result.ssl_expiry_date:%Y-%m-%d})'
                ),
            )
            result.has_alerts = True

    result.content_found = website.expected_text in content_text if website.expected_text else True

    if website.response_time_threshold_ms and total_time_ms > website.response_time_threshold_ms:
        Alert.objects.create(
            result=result,
            severity='medium',
            message=f'Response time exceeded threshold ({total_time_ms}ms > {website.response_time_threshold_ms}ms)',
        )
        result.has_alerts = True

    if status_code != website.expected_status_code:
        Alert.objects.create(
            result=result,
            severity='high',
            message=f'Unexpected status code {status_code} (expected {website.expected_status_code})',
        )
        result.has_alerts = True

    if not result.content_found:
        Alert.objects.create(
            result=result,
            severity='medium',
            message=f'Expected text "{website.expected_text}" not found',
        )
        result.has_alerts = True

    if not result.is_available:
        result.has_alerts = True

    # Performance score and grade.
    result.performance_score = compute_performance_score(
        ttfb_ms,
        total_time_ms,
        result.total_transfer_bytes,
        resource_count,
        result.compressed,
        cache_headers_ok,
    )
    result.performance_grade = grade_for_score(result.performance_score)

    # Exclude the current (still unsaved-updated) result so it is counted exactly
    # once. Otherwise it would be included here with its default is_available=False
    # and inflate both failed_checks and total_checks.
    previous_results = (
        CheckResult.objects.filter(website=website)
        .exclude(pk=result.pk)
        .order_by('-checked_at')
    )
    total_checks = previous_results.count() + 1
    failed_checks = previous_results.filter(is_available=False).count() + (0 if result.is_available else 1)
    result.total_checks = total_checks
    result.failed_checks = failed_checks
    result.availability_uptime_ratio = round((total_checks - failed_checks) / total_checks, 2) if total_checks else 0.0
    result.error_rate_percent = round((failed_checks / total_checks) * 100, 2) if total_checks else 0.0

    result.completed_at = timezone.now()
    result.save()

    if result.has_alerts:
        send_alert_email(website, result, 'Website monitoring alert triggered')

    result.refresh_from_db()
    return result


def send_alert_email(website: Website, result: CheckResult, reason: str) -> None:
    recipient = getattr(settings, 'ALERT_EMAIL_RECIPIENT', None)
    if not recipient:
        return

    message = EmailMessage()
    message['Subject'] = f'Performance alert for {website.name}'
    message['From'] = getattr(settings, 'DEFAULT_FROM_EMAIL', 'monitor@example.com')
    message['To'] = recipient
    message.set_content(
        f'Website: {website.name}\nURL: {website.url}\nReason: {reason}\nStatus: {result.status_code}\nResponse time: {result.response_time_ms}ms\nAvailable: {result.is_available}'
    )

    try:
        with smtplib.SMTP(getattr(settings, 'EMAIL_HOST', 'localhost'), getattr(settings, 'EMAIL_PORT', 25)) as smtp:
            smtp.send_message(message)
    except Exception:
        return
